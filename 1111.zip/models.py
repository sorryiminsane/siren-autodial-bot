from sqlalchemy import Column, Integer, String, Boolean, DateTime, BigInteger, ForeignKey
from datetime import datetime
import uuid
from database import Base

class Agent(Base):
    __tablename__ = 'agents'
    
    id = Column(Integer, primary_key=True)
    telegram_id = Column(BigInteger, unique=True, nullable=False)
    phone_number = Column(String, unique=True)
    caller_id = Column(String)
    autodial_caller_id = Column(String)
    route = Column(String(1))  # 'M', 'R', 'B' for manual calls
    autodial_trunk = Column(String(3)) # 'one' or 'two' for autodial calls
    username = Column(String)
    is_authorized = Column(Boolean, default=False)
    auto_dial = Column(Boolean, default=False)  # Private feature flag
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __repr__(self):
        return f"<Agent(telegram_id={self.telegram_id}, username={self.username})>"

class CallerIDHistory(Base):
    __tablename__ = 'caller_id_history'
    
    id = Column(Integer, primary_key=True)
    agent_id = Column(Integer, ForeignKey('agents.id'))
    old_caller_id = Column(String)
    new_caller_id = Column(String)
    changed_at = Column(DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f"<CallerIDHistory(agent_id={self.agent_id}, new_caller_id={self.new_caller_id})>"

class AutodialCampaign(Base):
    __tablename__ = 'autodial_campaigns'
    
    id = Column(Integer, primary_key=True)
    telegram_user_id = Column(BigInteger, ForeignKey('agents.telegram_id'))
    name = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f"<AutodialCampaign(id={self.id}, name={self.name})>"

class AutodialResponse(Base):
    __tablename__ = 'autodial_responses'
    
    id = Column(Integer, primary_key=True)
    campaign_id = Column(Integer, ForeignKey('autodial_campaigns.id'))
    phone_number = Column(String)
    response_digit = Column(String)
    timestamp = Column(DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f"<AutodialResponse(campaign_id={self.campaign_id}, phone_number={self.phone_number}, response={self.response_digit})>"